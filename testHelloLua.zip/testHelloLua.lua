--this is a test
function newFun()
    cclog("this is newFun.")
end
